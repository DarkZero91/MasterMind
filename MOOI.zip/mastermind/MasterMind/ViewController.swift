//
//  ViewController.swift
//  MasterMind
//
//  Created by J.B. Hoekstra on 23/02/2018.
//  Copyright © 2018 Team4. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var counter = 0
    var turn = 1
    
    @IBOutlet var Buttons: [UIButton]!
    
    @IBOutlet var colorSelection: [UIButton]!
    
    @IBOutlet weak var turnLabel: UILabel!
    
    @IBAction func touchButton(_ sender: UIButton) {
        let currentButton = colorSelection.index(of: sender)!
        Buttons[counter].backgroundColor = colorSelection[currentButton].backgroundColor
        if (counter == 3){
            counter = 0
            turn += 1
        }
        else{
            counter += 1
        }
        turnLabel.text = "Turn: \(turn)"
    }
    
    //TODO: confirmation pins

    //TODO: scaling buttons

}

