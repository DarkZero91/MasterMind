//
//  ViewController.swift
//  MasterMind
//
//  Created by J.B. Hoekstra on 23/02/2018.
//  Copyright © 2018 Team4. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var counter = 0
    var currentButton = 0
    
    @IBOutlet var Buttons: [UIButton]!
    
    @IBOutlet var colorSelection: [UIButton]!
    
    
    
    @IBAction func changeColor(_ sender: Any) {
//        print("\(colorSelection.index(of: sender))")
        Buttons[counter].backgroundColor = #colorLiteral(red: 1, green: 0.1075260308, blue: 0.0651132394, alpha: 1)
        counter = counter+1
    }
    


}

